import Vue from "vue";
import App from "./App.vue";
import Typewriter from "typewriter-effect/dist/core";
import GraphemeSplitter from "grapheme-splitter";

Vue.config.productionTip = false;

new Vue({
  render: (h) => h(App)
}).$mount("#app");

const innerdemo = document.getElementById("inner-demo-2");

const stringSplitter = (string) => {
  const splitter = new GraphemeSplitter();
  return splitter.splitGraphemes(string);
};

const typewriter = new Typewriter(innerdemo, {
  loop: true,
  delay: 45,
  stringSplitter
});

typewriter
  .typeString("Hey there, I'm Junhao 👋 ")
  .pauseFor(1000)
  .deleteAll()
  .typeString("I'm a CSc man 🌝 ")
  .pauseFor(1000)
  .deleteAll()
  .typeString("AI is my main direction")
  .pauseFor(1000)
  .deleteAll()
  .typeString("My research interests:")
  .pauseFor(1000)
  .deleteAll()
  .typeString("Neural Networks...")
  .pauseFor(1000)
  .deleteAll()
  .typeString("and Computer Vision")
  .pauseFor(1000)
  .deleteAll()
  .typeString("Also, I'm a...")
  .pauseFor(1000)
  .deleteAll()
  .typeString("Team Leader... ")
  .pauseFor(1000)
  .deleteAll()
  .typeString("with a strong interest in")
  .pauseFor(1000)
  .deleteAll()
  .typeString("Programming and Logic")
  .pauseFor(1000)
  .deleteAll()
  .typeString("To learn more about me")
  .pauseFor(1000)
  .deleteAll()
  .typeString("please check my website")
  .pauseFor(1000)
  .deleteAll()
  .typeString("junhaosong.com ❤️ ")
  .pauseFor(1000)
  .deleteAll()
  .start();
